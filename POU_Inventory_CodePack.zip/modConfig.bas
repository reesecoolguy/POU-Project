Attribute VB_Name = "modConfig"
Option Explicit
'==============================================================================
' modConfig - every setting the system uses lives here. Change behaviour here,
' not inside the forms.
'==============================================================================

' ---- Sheet / table names ----------------------------------------------------
Public Const SH_LAUNCHER As String = "Launcher"
Public Const SH_INVENTORY As String = "Inventory"
Public Const SH_TRANSACTIONS As String = "Transactions"
Public Const SH_AUDIT As String = "InventoryAudit"
Public Const SH_REORDER_QUEUE As String = "ReorderQueue"
Public Const SH_REORDER_REPORT As String = "ReorderReport"
Public Const SH_USERS As String = "Users"
Public Const SH_USAGE As String = "Usage Summary"
Public Const SH_ERRORLOG As String = "ErrorLog"
Public Const SH_HEALTH As String = "HealthCheck"
Public Const INVENTORY_TABLE As String = "Table1"

' ---- Inventory table headers (columns are found by header, not position) ----
Public Const HDR_ID As String = "Item ID"
Public Const HDR_NAME As String = "Item Name"
Public Const HDR_LOCATION As String = "Location"
Public Const HDR_MIN As String = "Min Qty"
Public Const HDR_MAX As String = "Max Qty"
Public Const HDR_ONHAND As String = "On Hand Qty"
Public Const HDR_BARCODE As String = "Barcode"
Public Const HDR_AREA As String = "Area:"

' ---- Users sheet columns ----------------------------------------------------
Public Const UCOL_BADGE As Long = 1     ' A  Badge ID
Public Const UCOL_NAME As Long = 2      ' B  Employee Name
Public Const UCOL_ROLE As Long = 3      ' C  Role   (ADMIN / OPERATOR; blank = OPERATOR)
Public Const UCOL_ACTIVE As Long = 4    ' D  Active (Y / N; blank = Y)

' ---- Transaction types ------------------------------------------------------
Public Const TXN_ADD As String = "ADD"
Public Const TXN_REMOVE As String = "REMOVE"
Public Const TXN_AUDIT As String = "AUDIT"
Public Const TXN_NEW As String = "NEW ITEM"

Public Const ROLE_ADMIN As String = "ADMIN"
Public Const ROLE_OPERATOR As String = "OPERATOR"

' ---- Business rules ---------------------------------------------------------
' Idle minutes before the badge session locks. A shared cabinet PC should be short.
Public Const SESSION_TIMEOUT_MIN As Long = 3
' True = log the user out after every submit (strictest accountability).
Public Const LOGOUT_AFTER_SUBMIT As Boolean = False
' True  = item is "low" when On Hand <= Min  (what the scanner used to warn on)
' False = item is "low" when On Hand <  Min  (what the Low Stock list used to show)
Public Const REORDER_AT_OR_BELOW_MIN As Boolean = True
' Largest quantity allowed in a single ADD (catches a part number scanned into Qty).
Public Const MAX_ADD_QTY As Long = 500
' Audit variances at or above this size need a Yes/No confirmation.
Public Const AUDIT_CONFIRM_VARIANCE As Long = 5
Public Const REQUIRE_ADMIN_FOR_AUDIT As Boolean = True
Public Const REQUIRE_ADMIN_FOR_ADD_ITEM As Boolean = True
' Save the workbook after every successful write (protects against crashes / power loss).
Public Const AUTO_SAVE As Boolean = True

' ---- Protection -------------------------------------------------------------
' CHANGE THIS, then lock the VBA project (Tools > VBAProject Properties > Protection)
' so the password can't be read.
Public Const SHEET_PASSWORD As String = "ChangeMe!2026"
