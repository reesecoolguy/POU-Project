# POU Inventory – Hardened Code Pack: Install & Test

Written against your current workbook (same sheet names, table name `Table1`, and form control names).
It was written and structure-checked outside Excel, so **install on a copy first** and run the test script below before you put it on the cabinet PC.

## What's in the pack

| File | Where it goes | Replaces |
|---|---|---|
| `modConfig.bas` | Import (new module) | — all settings and rules in one place |
| `modInventory.bas` | Import (new module) | `modReorderQueue`, all scattered sheet writes |
| `modSecurity.bas` | Import | old `modSecurity` |
| `modProtection.bas` | Import (new module) | — sheet locking |
| `modAdmin.bas` | Import | `modScannerUI`, `modUsageReport` |
| `frmInventoryScanner_code.txt` | Paste into form's code window | existing form code |
| `frmInventoryAudit_code.txt` | Paste into form's code window | existing form code |
| `frmAddItem1_code.txt` | Paste into form's code window | existing form code |
| `frmLowStock_code.txt` | Paste into form's code window | existing form code |
| `ThisWorkbook_code.txt` | Paste into `ThisWorkbook` | (empty today) |

## Install (about 20 minutes)

1. **Save a copy** of the workbook, for example `POU_Inventory_v2_TEST.xlsm`. Work only in the copy.
2. Press **Alt+F11** to open the VBA editor.
3. **Remove the old modules.** Right-click each module → Remove → **No** (don't export):
   `modScan`, `modScannerUI`, `modUsageReport`, `modReorderQueue`, `modSecurity`.
4. **Clear the old sheet code.** Double-click `Sheet4 (Scanner)`, delete the `Worksheet_Change` sub. Double-click `Sheet1`, delete the empty `CommandButton1_Click`.
5. **Import the 5 modules.** File → Import File → pick each `.bas` file.
6. **Replace the form code.** For each of the four forms: right-click → View Code → Ctrl+A → Delete → paste the matching `_code.txt` file.
7. **Paste the ThisWorkbook code.** Double-click `ThisWorkbook` and paste `ThisWorkbook_code.txt`.
8. **Set your password.** In `modConfig`, change `SHEET_PASSWORD`.
9. **Compile.** Debug → Compile VBAProject. It should finish with no message. If a line turns yellow or red, it's usually a control name that differs on your form. Send me the line.
10. **Change two form properties** in the designer:
    - `frmInventoryScanner.cboTransaction` → **Style = 2 - fmStyleDropDownList** (the code also sets this at runtime).
    - Optional: `txtBadgeScan` → **PasswordChar = \***.
11. **Set up the sheets.** Close the editor, press **Alt+F8**, and run these in order:
    1. `SetupNewColumns`. This adds the new headers to Transactions F:K, InventoryAudit G, ReorderQueue H, and Users C:D.
    2. On the **Users** sheet, type `ADMIN` in Role (column C) for supervisors, **including yourself**. Leave others blank (blank means OPERATOR). Put `N` in Active (column D) to disable a badge without deleting history.
    3. `RunHealthCheck`. This lists data problems on a new HealthCheck sheet. Fix them, especially duplicate IDs and blank On Hand values.
    4. `RebuildReorderQueue`. This replaces the stale queue with current data.
12. **Clean up the hidden sheets.** Delete the hidden `Scanner` sheet. It was only used by the old `modScan`. For `Dashboard`, delete it or replace its formulas:
    - Total Items `=ROWS(Table1[Item ID])`
    - Low Stock `=SUMPRODUCT(--(Table1[On Hand Qty]<=Table1[Min Qty]))`
    - Total Units `=SUM(Table1[On Hand Qty])`
    - Zero Stock `=COUNTIF(Table1[On Hand Qty],0)`
13. **Lock it down.** Run `LockWorkbook`. Then in the VBA editor, open Tools → VBAProject Properties → Protection, tick "Lock project for viewing", and set a password. Without that lock, anyone can read the sheet password from `modConfig`.
14. Save, close, reopen, and click **Enable Content**.

## Admin macros (Alt+F8)

| Macro | Use |
|---|---|
| `UnlockForMaintenance` | Asks for the password and unprotects data sheets for direct edits (those edits are **not** logged). |
| `LockWorkbook` | Re-protects. It also runs automatically every time the file opens. |
| `RunHealthCheck` | Data problem report. Run it weekly and before cycle counts. |
| `RebuildReorderQueue` | Re-derives the queue from current inventory. |
| `GenerateUsageReport` / `UsageLast30Days` | Usage by item, sorted high to low. |

## Settings worth deciding (modConfig)

| Setting | Default | Decide |
|---|---|---|
| `REORDER_AT_OR_BELOW_MIN` | True | On your current data, `<= Min` flags **71** items and `< Min` flags **9**. Pick the rule your buyer actually uses. |
| `SESSION_TIMEOUT_MIN` | 3 | A shared cabinet PC needs a short timeout so the next person isn't logged as you. |
| `LOGOUT_AFTER_SUBMIT` | False | True gives one badge scan per transaction (strictest). |
| `MAX_ADD_QTY` | 500 | Largest single ADD. Catches part numbers scanned into the Qty box. |
| `AUDIT_CONFIRM_VARIANCE` | 5 | Audit variances this large ask for confirmation. |
| `REQUIRE_ADMIN_FOR_AUDIT` / `_ADD_ITEM` | True | Operators can only ADD/REMOVE. |
| `AUTO_SAVE` | True | Saves after every write. Turn it off if saving to SharePoint is slow. |

## Test script (run on the copy)

| # | Do this | Expect |
|---|---|---|
| 1 | Launch scanner, scan an unknown badge | "Invalid badge" with a beep. ErrorLog gets a row. |
| 2 | Scan an operator badge | Name shown. Audit and Add New Part are greyed out. |
| 3 | Scan a valid part, REMOVE 1, Submit | Status shows the new On Hand. Transactions row filled through column K. |
| 4 | REMOVE more than On Hand | "Only N on hand". Nothing written. |
| 5 | Pick ADD, type 100593 in Qty, Submit | "over the 500 limit" message. Nothing written. |
| 6 | Double-click Submit fast | Exactly **one** Transactions row. |
| 7 | Scan a part, edit the barcode to another part number, then click Submit straight away | New item loads. Status says "check details, then Submit again". Nothing written until the second click. |
| 8 | REMOVE until On Hand ≤ Min | Yellow "LOW STOCK". Item appears in ReorderQueue with a positive Suggested Order. |
| 9 | ADD back above Min | Item is **removed** from ReorderQueue. |
| 10 | Scan a duplicated ID (e.g. K102516 before fixing) | "listed 2 times… fix duplicate first". |
| 11 | Wait past the timeout, scan a part | "Session expired – scan badge". |
| 12 | Admin badge → Audit → count differs by 5+ | Confirmation box. On Yes, InventoryAudit and Transactions (type AUDIT) both get a row. |
| 13 | Admin → Add New Part with an existing ID | "already exists". With a new ID, the row is added inside Table1 and the Barcode formula is intact. |
| 14 | Low Stock List → Generate Report | No blank rows. CRITICAL rows first. Timestamp in I1. |
| 15 | Close the scanner with the red X | Excel window comes back (not stuck minimized). |
| 16 | Try typing in the Inventory sheet | Excel blocks it (sheet protected). |
