Attribute VB_Name = "modAdmin"
Option Explicit
'==============================================================================
' modAdmin - launcher, reports and data health check.
' Replaces modScannerUI and modUsageReport. Delete modScan entirely.
'==============================================================================

' Assigned to the "LAUNCH INVENTORY SCANNER" button (same name as before).
Public Sub OpenScannerUI()
    On Error GoTo EH
    Application.WindowState = xlMinimized
    frmInventoryScanner.Show
    Application.WindowState = xlNormal
    Exit Sub
EH:
    Application.WindowState = xlNormal          ' never leave Excel stuck minimized
    LogError "OpenScannerUI", Err.Number & ": " & Err.Description
    MsgBox "Scanner could not start: " & Err.Description, vbCritical
End Sub

'------------------------------------------------------------------------------
' Usage report: total REMOVE qty per item, with item name, sorted high to low.
' Optional date window (0 = all history).
'------------------------------------------------------------------------------
Public Sub GenerateUsageReport(Optional ByVal lastNDays As Long = 0)
    Dim wsT As Worksheet, wsOut As Worksheet, dict As Object, cnt As Object
    Dim data As Variant, i As Long, lastRow As Long, key As String, k As Variant
    Dim it As InvItem, msg As String, out() As Variant, r As Long

    Set wsT = ThisWorkbook.Worksheets(SH_TRANSACTIONS)
    Set wsOut = ThisWorkbook.Worksheets(SH_USAGE)
    Set dict = CreateObject("Scripting.Dictionary")
    Set cnt = CreateObject("Scripting.Dictionary")

    lastRow = wsT.Cells(wsT.Rows.Count, 1).End(xlUp).Row
    If lastRow >= 2 Then
        data = wsT.Range("A2:D" & lastRow).Value
        For i = 1 To UBound(data, 1)
            If UCase$(CellText(data(i, 3))) = TXN_REMOVE Then
                If lastNDays = 0 Or (IsDate(data(i, 1)) And data(i, 1) >= Date - lastNDays) Then
                    key = NormalizeID(data(i, 2))
                    dict(key) = dict(key) + Val(data(i, 4))
                    cnt(key) = cnt(key) + 1
                End If
            End If
        Next i
    End If

    wsOut.Cells.Clear
    wsOut.Range("A1:D1").Value = Array("Item ID", "Item Name", "Total Removed", "# Transactions")
    wsOut.Range("F1").Value = "Generated " & Format$(Now, "m/d/yyyy h:nn") & _
                              IIf(lastNDays > 0, "  (last " & lastNDays & " days)", "  (all history)")
    If dict.Count > 0 Then
        ReDim out(1 To dict.Count, 1 To 4)
        r = 0
        For Each k In dict.Keys
            r = r + 1
            out(r, 1) = k
            If LoadItem(CStr(k), it, msg) Then out(r, 2) = it.ItemName Else out(r, 2) = "(" & msg & ")"
            out(r, 3) = dict(k)
            out(r, 4) = cnt(k)
        Next k
        wsOut.Range("A2").Resize(dict.Count, 4).Value = out
        wsOut.Range("A1").Resize(dict.Count + 1, 4).Sort Key1:=wsOut.Range("C1"), Order1:=xlDescending, Header:=xlYes
    End If
    wsOut.Rows(1).Font.Bold = True
    wsOut.Columns("A:D").AutoFit
    wsOut.Visible = xlSheetVisible
    wsOut.Activate
End Sub

Public Sub UsageLast30Days()
    GenerateUsageReport 30
End Sub

'------------------------------------------------------------------------------
' Health check: lists every data problem that would break a lookup or a count.
' Run it weekly, and before any physical inventory.
'------------------------------------------------------------------------------
Public Sub RunHealthCheck()
    Dim lo As ListObject, ws As Worksheet, data As Variant, i As Long, r As Long
    Dim cID As Long, cMin As Long, cMax As Long, cOH As Long, cBC As Long
    Dim seen As Object, key As String, mn As Long, mx As Long, oh As Long
    Dim okMin As Boolean, okMax As Boolean, okOH As Boolean, firstRow As Long

    Set lo = InvTable
    If lo.DataBodyRange Is Nothing Then MsgBox "Inventory table is empty.": Exit Sub
    cID = InvCol(HDR_ID): cMin = InvCol(HDR_MIN): cMax = InvCol(HDR_MAX)
    cOH = InvCol(HDR_ONHAND): cBC = InvCol(HDR_BARCODE)
    data = lo.DataBodyRange.Value
    firstRow = lo.DataBodyRange.Row
    Set seen = CreateObject("Scripting.Dictionary")

    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(SH_HEALTH)
    On Error GoTo 0
    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
        ws.Name = SH_HEALTH
    End If
    ws.Cells.Clear
    ws.Range("A1:D1").Value = Array("Sheet Row", "Item ID", "Problem", "Value")
    r = 1

    For i = 1 To UBound(data, 1)
        key = NormalizeID(data(i, cID))
        If Len(key) = 0 Then
            AddIssue ws, r, firstRow + i - 1, "", "Blank Item ID", ""
        Else
            If seen.Exists(key) Then
                AddIssue ws, r, firstRow + i - 1, key, "Duplicate Item ID (first at row " & seen(key) & ")", ""
            Else
                seen.Add key, firstRow + i - 1
            End If
            If CellText(data(i, cID)) <> key Then AddIssue ws, r, firstRow + i - 1, key, "ID has spaces/lower case/*", CellText(data(i, cID))
        End If

        okMin = ToLong(data(i, cMin), mn)
        okMax = ToLong(data(i, cMax), mx)
        okOH = ToLong(data(i, cOH), oh)
        If Not okMin Then AddIssue ws, r, firstRow + i - 1, key, "Min Qty blank/invalid", CellText(data(i, cMin))
        If Not okMax Then AddIssue ws, r, firstRow + i - 1, key, "Max Qty blank/invalid", CellText(data(i, cMax))
        If Not okOH Then AddIssue ws, r, firstRow + i - 1, key, "On Hand blank/invalid", CellText(data(i, cOH))
        If okMin And okMax Then If mn > mx Then AddIssue ws, r, firstRow + i - 1, key, "Min > Max", mn & " / " & mx
        If okMin And okMax Then If mx = 0 Then AddIssue ws, r, firstRow + i - 1, key, "Max is 0", ""
        If okOH And okMax Then If oh > mx Then AddIssue ws, r, firstRow + i - 1, key, "On Hand above Max", oh & " / " & mx
        If okOH Then If oh < 0 Then AddIssue ws, r, firstRow + i - 1, key, "Negative On Hand", oh
        If Not lo.ListColumns(HDR_BARCODE).DataBodyRange.Cells(i, 1).HasFormula Then
            AddIssue ws, r, firstRow + i - 1, key, "Barcode cell overwritten (no formula)", CellText(data(i, cBC))
        End If
    Next i

    ws.Rows(1).Font.Bold = True
    ws.Columns("A:D").AutoFit
    ws.Activate
    MsgBox IIf(r = 1, "No problems found.", (r - 1) & " problem(s) listed on the " & SH_HEALTH & " sheet."), vbInformation
End Sub

Private Sub AddIssue(ByVal ws As Worksheet, ByRef r As Long, ByVal sheetRow As Long, _
                     ByVal itemID As String, ByVal problem As String, ByVal v As Variant)
    r = r + 1
    ws.Cells(r, 1).Resize(1, 4).Value = Array(sheetRow, itemID, problem, v)
End Sub

'------------------------------------------------------------------------------
' One-time setup: adds the new header columns the upgraded code writes to.
' Safe to run more than once (only fills headers that are blank).
'------------------------------------------------------------------------------
Public Sub SetupNewColumns()
    Dim wsT As Worksheet, wsA As Worksheet, wsQ As Worksheet, wsU As Worksheet
    Set wsT = ThisWorkbook.Worksheets(SH_TRANSACTIONS)
    Set wsA = ThisWorkbook.Worksheets(SH_AUDIT)
    Set wsQ = ThisWorkbook.Worksheets(SH_REORDER_QUEUE)
    Set wsU = ThisWorkbook.Worksheets(SH_USERS)

    BeginWrite wsT: BeginWrite wsA: BeginWrite wsQ: BeginWrite wsU
    FillHeaders wsT, 6, Array("Qty Before", "Qty After", "Badge ID", "Txn ID", "Source", "Location")
    FillHeaders wsA, 7, Array("Badge ID")
    FillHeaders wsQ, 8, Array("Last Updated")
    FillHeaders wsU, 3, Array("Role", "Active")
    wsT.Columns("B").NumberFormat = "@"
    wsT.Columns("H").NumberFormat = "@"
    wsT.Rows(1).Font.Bold = True: wsA.Rows(1).Font.Bold = True
    wsQ.Rows(1).Font.Bold = True: wsU.Rows(1).Font.Bold = True
    EndWrite wsT: EndWrite wsA: EndWrite wsQ: EndWrite wsU

    MsgBox "Headers added." & vbCrLf & vbCrLf & _
           "Next: on the Users sheet, type ADMIN in the Role column for supervisors," & vbCrLf & _
           "then run RebuildReorderQueue and RunHealthCheck.", vbInformation
End Sub

Private Sub FillHeaders(ByVal ws As Worksheet, ByVal firstCol As Long, ByVal names As Variant)
    Dim i As Long
    For i = 0 To UBound(names)
        If Len(CellText(ws.Cells(1, firstCol + i).Value)) = 0 Then ws.Cells(1, firstCol + i).Value = names(i)
    Next i
End Sub
