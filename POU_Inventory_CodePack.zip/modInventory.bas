Attribute VB_Name = "modInventory"
Option Explicit
'==============================================================================
' modInventory - the ONLY place that reads or writes inventory quantities.
' Forms call these functions; they never touch the sheets directly.
'
' Every write:
'   * re-reads the live row (never trusts a cached copy)
'   * validates the numbers
'   * writes On Hand + one ledger row in Transactions (with before/after qty)
'   * rolls the On Hand back if the ledger write fails
'   * keeps ReorderQueue in sync (adds when low, removes when restocked)
'   * logs any error to the ErrorLog sheet
'==============================================================================

Public Type InvItem
    Index As Long          ' position in Table1 (ListRows index)
    ItemID As String
    ItemName As String
    Location As String
    Area As String
    MinQty As Long
    MaxQty As Long
    OnHand As Long
End Type

'------------------------------------------------------------------------------
' Basic helpers
'------------------------------------------------------------------------------
Public Function InvTable() As ListObject
    Set InvTable = ThisWorkbook.Worksheets(SH_INVENTORY).ListObjects(INVENTORY_TABLE)
End Function

Public Function InvCol(ByVal headerName As String) As Long
    InvCol = InvTable.ListColumns(headerName).Index
End Function

' Upper-case, trimmed, scanner "*" start/stop characters removed.
Public Function NormalizeID(ByVal v As Variant) As String
    If IsError(v) Or IsEmpty(v) Or IsNull(v) Then Exit Function
    NormalizeID = UCase$(Trim$(Replace(CStr(v), "*", "")))
End Function

Public Function CellText(ByVal v As Variant) As String
    If IsError(v) Or IsEmpty(v) Or IsNull(v) Then Exit Function
    CellText = Trim$(CStr(v))
End Function

' Converts v to a whole number. Returns False for blanks, text, decimals, errors.
Public Function ToLong(ByVal v As Variant, ByRef result As Long) As Boolean
    Dim d As Double
    If IsError(v) Or IsEmpty(v) Or IsNull(v) Then Exit Function
    If VarType(v) = vbString Then
        If Len(Trim$(v)) = 0 Then Exit Function
    End If
    If Not IsNumeric(v) Then Exit Function
    d = CDbl(v)
    If d <> Fix(d) Then Exit Function
    If d < -2147483647# Or d > 2147483647# Then Exit Function
    result = CLng(d)
    ToLong = True
End Function

Public Function IsLowStock(ByVal onHand As Long, ByVal minQty As Long) As Boolean
    If REORDER_AT_OR_BELOW_MIN Then
        IsLowStock = (onHand <= minQty)
    Else
        IsLowStock = (onHand < minQty)
    End If
End Function

Public Function SuggestedOrder(ByRef it As InvItem) As Long
    SuggestedOrder = it.MaxQty - it.OnHand
    If SuggestedOrder < 0 Then SuggestedOrder = 0
End Function

' Always returns a 2-D (1 To n, 1 To 1) array even when the range is one cell.
Private Function ColumnValues(ByVal rng As Range) As Variant
    Dim v As Variant
    If rng.Cells.Count = 1 Then
        ReDim v(1 To 1, 1 To 1)
        v(1, 1) = rng.Value
        ColumnValues = v
    Else
        ColumnValues = rng.Value
    End If
End Function

'------------------------------------------------------------------------------
' Lookups
'------------------------------------------------------------------------------
' Returns the Table1 row index of itemID (0 = not found). dupCount = matches found.
Public Function FindItemIndex(ByVal itemID As String, Optional ByRef dupCount As Long) As Long
    Dim lo As ListObject, ids As Variant, i As Long, key As String
    dupCount = 0
    Set lo = InvTable
    If lo.DataBodyRange Is Nothing Then Exit Function
    key = NormalizeID(itemID)
    If Len(key) = 0 Then Exit Function

    ids = ColumnValues(lo.ListColumns(HDR_ID).DataBodyRange)
    For i = 1 To UBound(ids, 1)
        If NormalizeID(ids(i, 1)) = key Then
            dupCount = dupCount + 1
            If FindItemIndex = 0 Then FindItemIndex = i
        End If
    Next i
End Function

Public Function LoadItemByIndex(ByVal idx As Long, ByRef it As InvItem, ByRef msg As String) As Boolean
    Dim lo As ListObject, r As Range
    Set lo = InvTable
    If idx < 1 Or idx > lo.ListRows.Count Then msg = "Item row no longer exists": Exit Function

    Set r = lo.ListRows(idx).Range
    it.Index = idx
    it.ItemID = NormalizeID(r.Cells(1, InvCol(HDR_ID)).Value)
    it.ItemName = CellText(r.Cells(1, InvCol(HDR_NAME)).Value)
    it.Location = CellText(r.Cells(1, InvCol(HDR_LOCATION)).Value)
    it.Area = CellText(r.Cells(1, InvCol(HDR_AREA)).Value)

    If Not ToLong(r.Cells(1, InvCol(HDR_ONHAND)).Value, it.OnHand) Then
        msg = it.ItemID & ": On Hand is blank or not a whole number - see a supervisor": Exit Function
    End If
    If Not ToLong(r.Cells(1, InvCol(HDR_MIN)).Value, it.MinQty) Then
        msg = it.ItemID & ": Min Qty is blank or invalid - see a supervisor": Exit Function
    End If
    If Not ToLong(r.Cells(1, InvCol(HDR_MAX)).Value, it.MaxQty) Then
        msg = it.ItemID & ": Max Qty is blank or invalid - see a supervisor": Exit Function
    End If
    LoadItemByIndex = True
End Function

' Finds itemID and loads its live values. Refuses duplicates.
Public Function LoadItem(ByVal itemID As String, ByRef it As InvItem, ByRef msg As String) As Boolean
    Dim idx As Long, dups As Long
    idx = FindItemIndex(itemID, dups)
    If idx = 0 Then msg = "Item not found: " & NormalizeID(itemID): Exit Function
    If dups > 1 Then
        msg = NormalizeID(itemID) & " is listed " & dups & " times in Inventory - fix duplicate first"
        Exit Function
    End If
    LoadItem = LoadItemByIndex(idx, it, msg)
End Function

'------------------------------------------------------------------------------
' ADD / REMOVE
'------------------------------------------------------------------------------
Public Function PostTransaction(ByVal itemID As String, ByVal txnType As String, ByVal qty As Long, _
                                ByVal source As String, ByRef resultMsg As String, _
                                Optional ByRef newOnHand As Long, Optional ByRef isLow As Boolean) As Boolean
    Dim it As InvItem, newQty As Long, onHandCell As Range
    Dim wsInv As Worksheet, wsLog As Worksheet
    Dim invWritten As Boolean, errText As String

    On Error GoTo EH

    If Not SessionActive() Then resultMsg = "Session expired - scan badge": Exit Function
    txnType = UCase$(Trim$(txnType))
    If txnType <> TXN_ADD And txnType <> TXN_REMOVE Then resultMsg = "Choose ADD or REMOVE": Exit Function
    If qty <= 0 Then resultMsg = "Quantity must be 1 or more": Exit Function
    If txnType = TXN_ADD And qty > MAX_ADD_QTY Then
        resultMsg = "ADD quantity over " & MAX_ADD_QTY & " - check the Qty field": Exit Function
    End If

    ' Re-read the LIVE row - never trust what the form loaded earlier
    If Not LoadItem(itemID, it, resultMsg) Then Exit Function

    If txnType = TXN_REMOVE Then
        If qty > it.OnHand Then resultMsg = "Only " & it.OnHand & " on hand - cannot remove " & qty: Exit Function
        newQty = it.OnHand - qty
    Else
        newQty = it.OnHand + qty
    End If

    Set wsInv = ThisWorkbook.Worksheets(SH_INVENTORY)
    Set wsLog = ThisWorkbook.Worksheets(SH_TRANSACTIONS)
    Set onHandCell = InvTable.ListRows(it.Index).Range.Cells(1, InvCol(HDR_ONHAND))

    BeginWrite wsInv
    BeginWrite wsLog
    onHandCell.Value = newQty
    invWritten = True
    WriteLedger it, txnType, qty, it.OnHand, newQty, source
    EndWrite wsLog
    EndWrite wsInv

    SyncReorderQueue it.Index

    it.OnHand = newQty
    newOnHand = newQty
    isLow = IsLowStock(newQty, it.MinQty)
    resultMsg = txnType & " " & qty & " x " & it.ItemID & "  ->  On Hand now " & newQty
    PostTransaction = True
    SaveQuietly
    Exit Function

EH:
    errText = Err.Number & ": " & Err.Description
    Resume RollBack
RollBack:
    On Error Resume Next
    If invWritten Then onHandCell.Value = it.OnHand      ' undo the quantity change
    EndWrite wsLog
    EndWrite wsInv
    LogError "PostTransaction", errText, itemID & " " & txnType & " " & qty
    resultMsg = "ERROR - nothing was saved (" & errText & ")"
    PostTransaction = False
End Function

'------------------------------------------------------------------------------
' Cycle-count / audit
'------------------------------------------------------------------------------
Public Function PostAudit(ByVal itemID As String, ByVal countedQty As Long, ByRef resultMsg As String) As Boolean
    Dim it As InvItem, variance As Long, onHandCell As Range
    Dim wsInv As Worksheet, wsAud As Worksheet, wsLog As Worksheet
    Dim r As Long, invWritten As Boolean, errText As String

    On Error GoTo EH

    If Not SessionActive() Then resultMsg = "Session expired - scan badge": Exit Function
    If countedQty < 0 Then resultMsg = "Counted quantity cannot be negative": Exit Function
    If Not LoadItem(itemID, it, resultMsg) Then Exit Function

    variance = countedQty - it.OnHand

    Set wsInv = ThisWorkbook.Worksheets(SH_INVENTORY)
    Set wsAud = ThisWorkbook.Worksheets(SH_AUDIT)
    Set wsLog = ThisWorkbook.Worksheets(SH_TRANSACTIONS)
    Set onHandCell = InvTable.ListRows(it.Index).Range.Cells(1, InvCol(HDR_ONHAND))

    BeginWrite wsInv: BeginWrite wsAud: BeginWrite wsLog

    onHandCell.Value = countedQty
    invWritten = True

    r = NextRow(wsAud)
    wsAud.Cells(r, 2).NumberFormat = "@"
    wsAud.Cells(r, 1).Resize(1, 7).Value = Array(Now, it.ItemID, it.OnHand, countedQty, variance, _
                                                 CurrentUserName, CurrentUserID)
    WriteLedger it, TXN_AUDIT, variance, it.OnHand, countedQty, "AUDIT"

    EndWrite wsLog: EndWrite wsAud: EndWrite wsInv

    SyncReorderQueue it.Index
    resultMsg = "Audit saved: " & it.ItemID & "  " & it.OnHand & " -> " & countedQty & _
                "  (variance " & Format$(variance, "+0;-0;0") & ")"
    PostAudit = True
    SaveQuietly
    Exit Function

EH:
    errText = Err.Number & ": " & Err.Description
    Resume RollBack
RollBack:
    On Error Resume Next
    If invWritten Then onHandCell.Value = it.OnHand
    EndWrite wsLog: EndWrite wsAud: EndWrite wsInv
    LogError "PostAudit", errText, itemID & " counted " & countedQty
    resultMsg = "ERROR - audit NOT saved (" & errText & ")"
    PostAudit = False
End Function

'------------------------------------------------------------------------------
' New item
'------------------------------------------------------------------------------
Public Function AddNewItem(ByVal itemID As String, ByVal itemName As String, ByVal location As String, _
                           ByVal area As String, ByVal minQty As Long, ByVal maxQty As Long, _
                           ByVal onHand As Long, ByRef resultMsg As String) As Boolean
    Dim lo As ListObject, lr As ListRow, ws As Worksheet, it As InvItem, errText As String

    On Error GoTo EH

    itemID = NormalizeID(itemID)
    If Len(itemID) = 0 Then resultMsg = "Item ID required": Exit Function
    If InStr(itemID, " ") > 0 Then resultMsg = "Item ID cannot contain spaces": Exit Function
    If FindItemIndex(itemID) > 0 Then resultMsg = itemID & " already exists": Exit Function

    Set lo = InvTable
    Set ws = lo.Parent

    ' Table rows can't be added on a protected sheet, even from VBA
    BeginWrite ws
    Set lr = lo.ListRows.Add(AlwaysInsert:=True)
    lr.Range.Cells(1, InvCol(HDR_ID)).NumberFormat = "@"
    lr.Range.Cells(1, InvCol(HDR_ID)).Value = itemID
    lr.Range.Cells(1, InvCol(HDR_NAME)).Value = Trim$(itemName)
    lr.Range.Cells(1, InvCol(HDR_LOCATION)).Value = UCase$(Trim$(location))
    lr.Range.Cells(1, InvCol(HDR_AREA)).Value = Trim$(area)
    lr.Range.Cells(1, InvCol(HDR_MIN)).Value = minQty
    lr.Range.Cells(1, InvCol(HDR_MAX)).Value = maxQty
    lr.Range.Cells(1, InvCol(HDR_ONHAND)).Value = onHand
    ' Barcode column is a calculated column - Excel fills it automatically.
    EndWrite ws

    it.Index = lr.Index: it.ItemID = itemID: it.ItemName = itemName
    it.Location = location: it.Area = area
    it.MinQty = minQty: it.MaxQty = maxQty: it.OnHand = onHand

    BeginWrite ThisWorkbook.Worksheets(SH_TRANSACTIONS)
    WriteLedger it, TXN_NEW, onHand, 0, onHand, "ADD ITEM"
    EndWrite ThisWorkbook.Worksheets(SH_TRANSACTIONS)

    SyncReorderQueue it.Index
    resultMsg = itemID & " added"
    AddNewItem = True
    SaveQuietly
    Exit Function

EH:
    errText = Err.Number & ": " & Err.Description
    Resume Cleanup
Cleanup:
    On Error Resume Next
    EndWrite ws
    EndWrite ThisWorkbook.Worksheets(SH_TRANSACTIONS)
    LogError "AddNewItem", errText, itemID
    resultMsg = "ERROR - item NOT added (" & errText & ")"
    AddNewItem = False
End Function

'------------------------------------------------------------------------------
' Ledger: one row per change. Columns A-E match the original layout so old
' reports keep working; F-K are new.
'   A Timestamp | B Item ID | C Type | D Qty | E User | F Qty Before | G Qty After
'   H Badge ID  | I Txn ID  | J Source | K Location
'------------------------------------------------------------------------------
Private Sub WriteLedger(ByRef it As InvItem, ByVal txnType As String, ByVal qty As Long, _
                        ByVal qtyBefore As Long, ByVal qtyAfter As Long, ByVal source As String)
    Dim ws As Worksheet, r As Long
    Set ws = ThisWorkbook.Worksheets(SH_TRANSACTIONS)
    r = NextRow(ws)
    ws.Cells(r, 2).NumberFormat = "@"          ' keep 100416 as text, same as K-numbers
    ws.Cells(r, 8).NumberFormat = "@"
    ws.Cells(r, 1).Resize(1, 11).Value = Array(Now, it.ItemID, txnType, qty, CurrentUserName, _
                                              qtyBefore, qtyAfter, CurrentUserID, _
                                              Format$(Now, "yyyymmdd-hhnnss") & "-" & r, source, it.Location)
    ws.Cells(r, 1).NumberFormat = "m/d/yyyy h:mm:ss"
End Sub

Public Function NextRow(ByVal ws As Worksheet) As Long
    NextRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
End Function

'------------------------------------------------------------------------------
' Reorder queue - one row per low item; removed automatically when restocked.
'   A Item ID | B Name | C On Hand | D Min | E Max | F Suggested Order
'   G Date Added | H Last Updated
'------------------------------------------------------------------------------
Public Sub SyncReorderQueue(ByVal idx As Long)
    Dim it As InvItem, msg As String, ws As Worksheet
    Dim r As Long, lastR As Long, found As Long

    On Error GoTo EH
    If Not LoadItemByIndex(idx, it, msg) Then Exit Sub

    Set ws = ThisWorkbook.Worksheets(SH_REORDER_QUEUE)
    lastR = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    For r = 2 To lastR
        If NormalizeID(ws.Cells(r, 1).Value) = it.ItemID Then found = r: Exit For
    Next r

    BeginWrite ws
    If IsLowStock(it.OnHand, it.MinQty) Then
        If found = 0 Then
            found = lastR + 1
            ws.Cells(found, 1).NumberFormat = "@"
            ws.Cells(found, 1).Value = it.ItemID
            ws.Cells(found, 7).Value = Now
        End If
        ws.Cells(found, 2).Resize(1, 5).Value = Array(it.ItemName, it.OnHand, it.MinQty, it.MaxQty, SuggestedOrder(it))
        ws.Cells(found, 8).Value = Now
    ElseIf found > 0 Then
        ws.Rows(found).Delete
    End If
    EndWrite ws
    Exit Sub
EH:
    LogError "SyncReorderQueue", Err.Number & ": " & Err.Description, CStr(idx)
    On Error Resume Next
    EndWrite ws
End Sub

' Admin: rebuild the whole queue from current inventory (fixes stale/negative rows).
Public Sub RebuildReorderQueue()
    Dim ws As Worksheet, lo As ListObject, i As Long
    Set ws = ThisWorkbook.Worksheets(SH_REORDER_QUEUE)
    Set lo = InvTable
    BeginWrite ws
    ws.Range("A2:H" & ws.Rows.Count).ClearContents
    ws.Range("A1:H1").Value = Array("Item ID", "Name", "On Hand", "Min", "Max", _
                                    "Suggested Order", "Date Added", "Last Updated")
    EndWrite ws
    For i = 1 To lo.ListRows.Count
        SyncReorderQueue i
    Next i
    MsgBox "Reorder queue rebuilt: " & (NextRow(ws) - 2) & " item(s) low.", vbInformation
End Sub

'------------------------------------------------------------------------------
' Error log + save
'------------------------------------------------------------------------------
Public Sub LogError(ByVal procName As String, ByVal errText As String, Optional ByVal context As String = "")
    Dim ws As Worksheet, r As Long
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(SH_ERRORLOG)
    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
        ws.Name = SH_ERRORLOG
        ws.Range("A1:E1").Value = Array("Timestamp", "Procedure", "Error", "Context", "User")
    End If
    ws.Unprotect Password:=SHEET_PASSWORD
    r = NextRow(ws)
    ws.Cells(r, 1).Resize(1, 5).Value = Array(Now, procName, errText, context, CurrentUserName)
    ProtectSheet ws
End Sub

Public Sub SaveQuietly()
    If Not AUTO_SAVE Then Exit Sub
    On Error Resume Next
    Application.DisplayAlerts = False
    ThisWorkbook.Save
    Application.DisplayAlerts = True
    If Err.Number <> 0 Then LogError "SaveQuietly", Err.Number & ": " & Err.Description
End Sub
