Attribute VB_Name = "modSecurity"
Option Explicit
'==============================================================================
' modSecurity - badge login, session timeout, roles.
' Replaces the old modSecurity (keeps the same public variable names so any
' other code that reads CurrentUserName still works).
'==============================================================================

Public CurrentUserID As String
Public CurrentUserName As String
Public CurrentUserRole As String
Public LastActivityTime As Date

Public Function LoginWithBadge(ByVal badge As String, ByRef msg As String) As Boolean
    Dim ws As Worksheet, lastRow As Long, i As Long, key As String, activeFlag As String

    Logout
    key = NormalizeID(badge)
    If Len(key) = 0 Then msg = "Scan badge": Exit Function

    Set ws = ThisWorkbook.Worksheets(SH_USERS)
    lastRow = ws.Cells(ws.Rows.Count, UCOL_BADGE).End(xlUp).Row

    For i = 2 To lastRow
        If NormalizeID(ws.Cells(i, UCOL_BADGE).Value) = key Then
            activeFlag = UCase$(CellText(ws.Cells(i, UCOL_ACTIVE).Value))
            If activeFlag = "N" Or activeFlag = "NO" Or activeFlag = "FALSE" Then
                msg = "Badge is inactive - see a supervisor"
                LogError "Login", "Inactive badge used", key
                Exit Function
            End If
            CurrentUserID = key
            CurrentUserName = CellText(ws.Cells(i, UCOL_NAME).Value)
            CurrentUserRole = UCase$(CellText(ws.Cells(i, UCOL_ROLE).Value))
            If Len(CurrentUserRole) = 0 Then CurrentUserRole = ROLE_OPERATOR
            LastActivityTime = Now
            msg = "Welcome, " & CurrentUserName
            LoginWithBadge = True
            Exit Function
        End If
    Next i

    msg = "Invalid badge"
    LogError "Login", "Unknown badge scanned", key
End Function

Public Sub Logout()
    CurrentUserID = ""
    CurrentUserName = ""
    CurrentUserRole = ""
    LastActivityTime = 0
End Sub

' True if someone is logged in and has not been idle too long. Does NOT extend the session.
Public Function SessionActive() As Boolean
    If Len(CurrentUserID) = 0 Then Exit Function
    If DateDiff("s", LastActivityTime, Now) >= SESSION_TIMEOUT_MIN * 60 Then
        Logout
        Exit Function
    End If
    SessionActive = True
End Function

' Call on every user action that should keep the session alive.
Public Sub TouchSession()
    If Len(CurrentUserID) > 0 Then LastActivityTime = Now
End Sub

' Kept for compatibility with the old code.
Public Function SessionExpired() As Boolean
    SessionExpired = Not SessionActive()
End Function

Public Function IsAdmin() As Boolean
    IsAdmin = (CurrentUserRole = ROLE_ADMIN)
End Function
