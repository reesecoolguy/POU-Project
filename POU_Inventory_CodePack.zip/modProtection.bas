Attribute VB_Name = "modProtection"
Option Explicit
'==============================================================================
' modProtection - keeps people from typing directly into the data sheets.
' All changes have to go through the forms, so all changes get logged.
'==============================================================================

Private mMaintenance As Boolean     ' True while an admin has unlocked the workbook

Public Function ProtectedSheetNames() As Variant
    ProtectedSheetNames = Array(SH_INVENTORY, SH_TRANSACTIONS, SH_AUDIT, SH_REORDER_QUEUE, SH_USERS, SH_ERRORLOG)
End Function

Public Sub ProtectSheet(ByVal ws As Worksheet)
    If mMaintenance Then Exit Sub
    ws.Protect Password:=SHEET_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=True, _
               AllowFiltering:=True, AllowFormattingColumns:=True
    ws.EnableSelection = xlNoRestrictions
End Sub

' Wrap every write in BeginWrite / EndWrite.
Public Sub BeginWrite(ByVal ws As Worksheet)
    ws.Unprotect Password:=SHEET_PASSWORD
End Sub

Public Sub EndWrite(ByVal ws As Worksheet)
    ProtectSheet ws
End Sub

' Runs from Workbook_Open. Protects data sheets and hides the badge list.
Public Sub LockWorkbook()
    Dim nm As Variant, ws As Worksheet
    mMaintenance = False
    On Error Resume Next
    For Each nm In ProtectedSheetNames()
        Set ws = Nothing
        Set ws = ThisWorkbook.Worksheets(CStr(nm))
        If Not ws Is Nothing Then ProtectSheet ws
    Next nm
    ThisWorkbook.Worksheets(SH_USERS).Visible = xlSheetVeryHidden
    ThisWorkbook.Worksheets(SH_ERRORLOG).Visible = xlSheetHidden
End Sub

' Admin maintenance: Alt+F8 > UnlockForMaintenance. Run LockWorkbook when done
' (it also runs automatically the next time the file opens).
Public Sub UnlockForMaintenance()
    Dim pw As String, nm As Variant, ws As Worksheet
    pw = InputBox("Admin password:", "Unlock inventory workbook")
    If pw <> SHEET_PASSWORD Then
        If Len(pw) > 0 Then LogError "UnlockForMaintenance", "Wrong password entered"
        Exit Sub
    End If
    mMaintenance = True
    On Error Resume Next
    For Each nm In ProtectedSheetNames()
        Set ws = Nothing
        Set ws = ThisWorkbook.Worksheets(CStr(nm))
        If Not ws Is Nothing Then ws.Unprotect Password:=SHEET_PASSWORD
    Next nm
    ThisWorkbook.Worksheets(SH_USERS).Visible = xlSheetVisible
    MsgBox "Unlocked. Direct edits are NOT logged - run LockWorkbook when finished.", vbExclamation
End Sub
